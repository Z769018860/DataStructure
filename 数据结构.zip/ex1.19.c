#include <stdio.h>
#define MAXINT 1000000
#define ARRSIZE 10000
int a[ARRSIZE];
void com(int n);
int main()
{
    int n;
    scanf("%d",&n);
    com(n);
    return 0;
}
void com(int n)
{
    int i;
    a[0]=1;
    if (n>ARRSIZE)
    {
        printf("%d",a[0]);
        for (i=1;i<ARRSIZE;i++)
            if (a[i-1]*i*2>MAXINT)
            {
                printf("ERROR:LARGER THAN MAXINT!\N");
                exit(0);
            }
            else
            {
                a[i]=a[i-1]*i*2;
                printf(" %d",a[i]);
            }
        printf("\n");
        printf("ERROR:n is larger than arrsize!\n");
    }
    else
    {
        printf("%d",a[0]);
        for (i=1;i<n;i++)
            if (a[i-1]*i*2>MAXINT)
            {
                printf("ERROR:LARGER THAN MAXINT!\N");
                exit(0);
            }
            else
            {
                a[i]=a[i-1]*i*2;
                printf(" %d",a[i]);
            }
        printf("\n");
    }
}
