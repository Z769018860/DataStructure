#include <stdio.h>
#define MAXLEN 1000
int a[MAXLEN],b[MAXLEN],aa[MAXLEN],bb[MAXLEN];
void compare(int len1,int len2);
int main()
{
    int len1,i,data,len2;
    scanf("%d",&len1);
    for (i=0;i<len1;i++)
        scanf("%d",&a[i]);
    scanf("%d",&len2);
    for (i=0;i<len2;i++)
        scanf("%d",&b[i]);
    compare(len1,len2);
    return 0;
}
void compare(int len1,int len2)
{
    int i=0;
    while ((a[i]==b[i])&&(len1>0)&&(len2>0))
    {
        i++;
        len1--;
        len2--;
    }
    if ((len1==len2)&&(len1==0))
        printf("A=B\n");
    if (((len1==0)&&(len2>len1))||(a[i]<b[i]))
        printf("A<B\n");
    if (((len2==0)&&(len1>len2))||(a[i]>b[i]))
        printf("A>B\n");
}
